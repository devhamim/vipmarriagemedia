@extends('user.master.usermaster')
@php
    $me=auth()->user();
@endphp
@push('css')
<style>
    .form-group {
    margin-bottom: 4px !important;
}

.col-form-label {
    padding-top: calc(0.375rem + 1px);
    padding-bottom: 0px !important;
    margin-bottom: 0;
    font-size: inherit;
    line-height: 1.5;
}
</style>

@endpush
@section('content')
<br>
<div class="container py-2 bg-white">
    <div class="row text-center">
        <div class="col-md-12 text-center">
            <div class="overflow-hidden mb-1">
            </div>
            <form action="{{ route('socialCulture', $me->id) }}" role="form" method="POST"
                class="needs-validation" enctype="multipart/form-data">
                @csrf
                <div class="col-md-12 text-center">
                    <h5>Social, Culture Background and Interests</h5>
                    <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Mother
                            Tongue</label>
                        <div class="col-lg-9">
                            <select class="form-control" name="mother_tongue" id="" required>
                                <option value="">Select...</option>
                                @foreach($userSettingFields[30]->values as $value)
                                    <option value="{{ $value->title }}">
                                        {{ $value->title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>


                    {{-- <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Country
                            of
                            Birth </label>
                        <div class="col-lg-9">
                            <select class="form-control" name="country" id="" required>
                                    <option value="">Select...</option>
                                    @foreach($userSettingFields[2]->values as $value)
                                        <option value="{{ $value->title }}">
                                            {{ $value->title }}</option>
                                    @endforeach
                            </select>
                        </div>
                    </div> --}}
                    <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Grew
                            Up
                            In</label>
                        <div class="col-lg-9">
                            <select class="form-control" name="grewup_in" id="" required>
                                    <option value="">select...</option>
                                    @foreach($userSettingFields[2]->values as $value)
                                        <option value="{{ $value->title }}">
                                            {{ $value->title }}</option>
                                    @endforeach
                            </select>
                        </div>
                    </div>
                    {{-- <div class="form-group row">
                        <label class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Personal
                            Values</label>
                        <div class="col-lg-9">
                            <select class="form-control" name="personal_value" id="" required>
                                    <option value="">Select...</option>
                                    @foreach($userSettingFields[45]->values as $value)
                                        <option value="{{ $value->title }}">
                                            {{ $value->title }}</option>
                                    @endforeach
                            </select>
                        </div>
                    </div> --}}
                    <div class="form-group row">
                        <label class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Can
                            Speak</label>
                        <div class="col-lg-9">
                            <select class="form-control select2" name="can_speak[]" id="" required multiple>
                                    <option value="">Select...</option>

                                    @foreach($userSettingFields[31]->values as $value)
                                        <option>{{ $value->title }}</option>
                                    @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Music</label>
                        <div class="col-lg-9">
                            <select class="form-control select2 w-100" name="music[]" id="" required multiple
                                multiple="multiple" data-placeholder="Select Music"
                                data-dropdown-css-class="select2-purple">
                                <option value="">Select...</option>
                                @foreach($userSettingFields[37]->values as $value)
                                    <option>{{ $value->title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Book</label>
                        <div class="col-lg-9">
                            <select class="form-control select2" name="book[]" id="" required multiple>
                                <option value="">Select...</option>
                                @foreach($userSettingFields[36]->values as $value)
                                    <option>{{ $value->title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Cooking</label>
                        <div class="col-lg-9">
                            <select class="form-control select2" name="cooking[]" id="" required multiple>
                                <option value="">Select...</option>
                                @foreach($userSettingFields[35]->values as $value)
                                    <option>{{ $value->title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Movie</label>
                        <div class="col-lg-9">
                            <select class="form-control select2" multiple name="movie[]" id="" required>
                                <option value="">Select...</option>
                                @foreach($userSettingFields[38]->values as $value)
                                    <option>{{ $value->title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    {{-- <div class="form-group row">
                        <label
                            class="col-lg-3 font-weight-bold text-dark col-form-label form-control-label text-2 required">Dress
                            Style</label>
                        <div class="col-lg-9">
                            <select class="form-control select2" multiple name="dress[]" id="" required>


                                <option value="">Select...</option>

                                @foreach($userSettingFields[19]->values as $value)
                                    <option>{{ $value->title }}</option>
                                @endforeach



                            </select>
                        </div>
                    </div> --}}



                </div>


                <div class="form-group row">
                    <div class="form-group col-lg-9">

                    </div>
                    <div class="form-group col-lg-3">
                        <input type="submit" value="Save" class="btn btn-primary btn-modern float-right"
                            data-loading-text="Loading...">
                    </div>
                </div>
            </form>
        </div>


    </div>


</div>
<br>

@endsection
