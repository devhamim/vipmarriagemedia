<div class="card-container" style="margin-top: -30px;height: 250px;">
                <div class="card" style="padding: 0px 10px 0px;">
                    <div class="front" style="height: 250px;">
                        <div class="cover" style="height: 60px;">
                            <img src="{{asset('assets/rc/x_rotating_card_v1.4/images/rotating_card_thumb3.png')}}"/>
                        </div>
                        <div class="user">
                            <img class="img-circle" src="{{asset('assets/rc/x_rotating_card_v1.4/images/rotating_card_profile.png')}}"/>
                        </div>
                        <div class="content" style="min-height: 50px;padding: 0px 10px 0px;">
                            <div class="main" style="min-height: 50px;">
                                <h3 class="name" style="font-size: 17px;margin: 0;">Jerin Julia
                                <i class="fa fa-circle text-green w3-small"></i>
                                </h3>
                                <p class="profession" style="font-size: 15px;margin-bottom: 0;">Dentist</p>
                                <p class="text-center">"I'm the new Sinatra, and since I made it here I can make it anywhere, yeah, they love me everywhere"</p>
                            </div>
                            {{-- <div class="footer" style="margin: 0;padding: 0px;">
                                <i class="fa fa-mail-forward"></i> Auto Rotation
                            </div> --}}
                        </div>
                    </div> <!-- end front panel -->
                    <div class="back" style="height: 250px;">
                        <div class="header">
                            <h5 class="motto">"To be or not to be, this is my awesome motto!"</h5>
                        </div>
                        {{-- <div class="content">
                            <div class="main">
                                <h4 class="text-center">Job Description</h4>
                                <p class="text-center">Web design, Adobe Photoshop, HTML5, CSS3, Corel and many others...</p>

                                <div class="stats-container">
                                    <div class="stats">
                                        <h4>235</h4>
                                        <p>
                                            Followers
                                        </p>
                                    </div>
                                    <div class="stats">
                                        <h4>114</h4>
                                        <p>
                                            Following
                                        </p>
                                    </div>
                                    <div class="stats">
                                        <h4>35</h4>
                                        <p>
                                            Projects
                                        </p>
                                    </div>
                                </div>

                            </div>
                        </div> --}}
                        <div class="footer">
                            <div class="social-links text-center">
                                <a href="" class="facebook"><i class="fa fa-facebook fa-fw"></i></a>
                                <a href="" class="google"><i class="fa fa-google-plus fa-fw"></i></a>
                                <a href=""><i class="fa fa-twitter fa-fw"></i></a>
                            </div>
                        </div>
                    </div> <!-- end back panel -->
                </div> <!-- end card -->
            </div> <!-- end card-container --> 