 
 

<footer class="main-footer" style="background-image: url({{asset("img/amb6.png")}});padding: 0;border-top: none;">

 
<div class="hidden-xs" style="background-color: #046F90;">

<div class="container">
	<div class="row">
	<div class="col-sm-11 col-sm-offset-1">
		<div   style="height: 48px;">
		<ul>
		  <li><a href="#home" >ABOUT</a></li>
		  <li><a href="#press">PRESS</a></li>
		  <li><a href="#contact">TERMS OF USE</a></li>
		  <li ><a href="#about">FAQ</a></li>
		  <li ><a href="#about">PRIVACY POLICY</a></li>
		  <li ><a href="#about">CONTACT US</a></li>
		</ul>
	</div>
	</div>
</div>
</div>
	

	
</div>
<div class="container">
	<div class="row">
		<div class="col-sm-4 text-center">
			<h3 style="color: #fff;" class="footer-h3">SIGNUP FOR NEWS LETTER</h3>
		
	</div>
		<div class="col-sm-4 "><img class="img-responsive" src="{{asset('img/weaccept.png')}}" style="border-top: 1px solid #005970;"></div>
		<div class="col-sm-4 text-center">
			<h3 style="color: #fff;" class="footer-h3">&copy; Copyright: BD Ambulance {{date('Y')}}</h3>
		</div>
	</div>
</div>
 
{{--     <strong>Copyright &copy; 2014-{{date('Y')}} <a target="_blanck" href="{{url('https://www.uttarainfotech.com/')}}">Uttara Info Tech</a>.</strong> All rights
    reserved. --}}

  </footer>