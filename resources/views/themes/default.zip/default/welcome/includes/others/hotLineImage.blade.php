<div class=" text-center w3-hover-shadow">
<div class="box box-widget mb-1">
  <div class="box-body">
     <a href="+{{ bdMobile(env('CONTACT_MOBILE1')) }}"><i class="fa fa-phone"></i> +{{ bdMobile(env('CONTACT_MOBILE1')) }}</a>
  </div>
</div>
</div>