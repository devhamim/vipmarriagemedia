 

@include('welcome.includes.others.hotLineImage')

{{-- <div align="center">
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-3322244656717684"
     data-ad-slot="7937748008"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div> --}}
 
<div class="w3-hover-shadow">
<div class="box box-widget">         
<div class="box-body">

@include('welcome.includes.others.fbPageArea')


</div>
</div>
</div>

 