<div class="fb-page"
  data-href="https://www.facebook.com/taslimamediabd" 
  data-width="300"
  data-hide-cover="false"
  data-tabs="timeline,messages"
  data-show-facepile="true"></div>