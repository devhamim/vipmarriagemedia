@if(isset($topAd))
{!! $topAd->description !!}
@endif