@if(isset($frontLeft2))
{!! $frontLeft2->description !!}
@endif
