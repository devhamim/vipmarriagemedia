@if(isset($topOfDetails1))
{!! $topOfDetails1->description !!}
@endif