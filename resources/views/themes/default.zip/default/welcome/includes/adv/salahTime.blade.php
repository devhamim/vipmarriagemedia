@if(isset($salahTime))
{!! $salahTime->description !!}
@endif