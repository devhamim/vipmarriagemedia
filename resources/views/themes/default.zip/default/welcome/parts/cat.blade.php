<div class="container">
  <section class="content">

<div class="row">
  <div class="col-sm-9">

    <div class="row">
      <div class="col-sm-8">

        <div class="w3-display-container w3-text-white">
    <img src="{{asset('img/photo2.png')}}" alt="Lights" style="width:100%">
    <div class="w3-xlarge w3-display-bottomleft w3-padding">LONDON 60&deg; F</div>
  </div>
      </div>

      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>

      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>

      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>

      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>

      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>

      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>

      <div class="col-sm-4">
        <div class="box">
          <div class="box-body box-profile">
            <img class="img-responsive" src="{{asset('img/photo2.png')}}" alt="User profile picture">

            <h3 class="profile-username">খালেদার মুক্তির দাবি নিয়ে জনগণের কাছে যাব: রিজভী</h3>

            <p class="text-muted">কারাবন্দী বিএনপি চেয়ারপার্সন খালেদা জিয়ার মুক্তির দাবি নিয়ে জনগণের কাছে যাওয়ার কথা জানিয়েছেন সিনিয়র যুগ্ম মহাসচিব…</p>
          </div>
          <!-- /.box-body -->
       </div>
      </div>
    </div>



  </div>

  <div class="col-sm-3">
    <div class="box">
    <div style="margin-bottom: 12px;" class="w3-bar w3-black">
      <button class="w3-bar-item w3-button" onclick="opentab2('Tokyo2')">সর্বশেষ খবর</button>
  </div>



    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>

    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>

    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>

    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>

    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>

    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>

    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>

    <div class="attachment-block clearfix">
      <img class="attachment-img" src="{{asset('img/photo1.png')}}" alt="Attachment Image">
      <div class="attachment-pushed">
        <h4 class="attachment-heading"><a href="http://www.lipsum.com/">text generator</a></h4>
        <p>Description about the attachmente.... <a href="#">more</a></p>
      </div>
    </div>


    </div>
  </div>
</div>

    
</section>

  
</div>
