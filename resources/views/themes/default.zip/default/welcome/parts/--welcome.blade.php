<div class="page-header header-filter clear-filters purple-filters" data-parallax="true" style="background-image: url({{asset('mk/mk/BS4/assets/img/kit/bg2.jpg')}});">
    <div class="container front-brand">
        <div class="row">
            <div class="col-md-8 ml-auto mr-auto">
                <div class="brand">
                    <h1>Bangali Muslim Marriage</h1>
                    <h3>The trusted source for your soulmate</h3>
                </div> 

            </div>
        </div>


        <div class="d-none d-sm-block">
            <br> <br> <br>

            @include('welcome.includes.forms.welcomeForm')
        </div>

    </div>


</div>


<div class="main main-raised">
    <div class="section section-basic" style="padding: 20px;">

@include('welcome.includes.others.usersOnline')
</div>
</div>