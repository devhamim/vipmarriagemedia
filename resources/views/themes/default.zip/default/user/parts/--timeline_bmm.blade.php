
  <div class="main main-raised">
    <div class="profile-content">
        <div class="container">
    <div class="row">
        <div class="col-sm-12">
            
 

@include('user.includes.others.profileHead')

<br> 

<div class="row">
    <div class="col-sm-3">

@include('user.includes.others.myLeftLinks')

        
    </div>
    <div class="col-sm-9">

        <div class="row">
            <div class="col-sm-6">
                @include('user.message.includes.myMessageAll')
            </div>
            <div class="col-sm-6">
                @include('user.includes.others.myVisitorsAll')
            </div>
        </div>



        
    </div>
</div>
 

</div>
</div>
</div>
        </div>
    </div>
