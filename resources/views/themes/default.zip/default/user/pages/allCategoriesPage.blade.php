@php
/*
---------------------------------------------------
All Categories Page
Displays all the content categories inside the website
---------------------------------------------------
*/
@endphp
@extends('user.layouts.primaryLayout')

@section('title')
page title
@endsection

@section('sitebody')
Page Contents
@endsection
