@php
/*
---------------------------------------------------
All tags Page
Displays all the content tags used inside
the website.
---------------------------------------------------
*/
@endphp
@extends('user.layouts.primaryLayout')

@section('title')
page title
@endsection

@section('sitebody')
Page Contents
@endsection
