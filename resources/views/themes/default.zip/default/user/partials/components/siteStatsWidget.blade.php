@php
/*
--------------------------------------------------------------------------
| Site stats widget
|---------------------------------------------------------------------------
| Responsibility: Displaying stats of the website such as question solved
| user joined.
*/
@endphp
<div class="left-widget" style="border:1px solid #4C5899;font-weight:bolder;">
    <div class="p-2">
        <div class="row py-2">
            <div class="col-md-6">
                13121 Problems
            </div>
            <div class="col-md-6">
                43247 Users
            </div>
        </div>

        <div class="row py-2">
            <div class="col-md-6">
                80980980 Solutions
            </div>
            <div class="col-md-6">
                4733 Live
            </div>
        </div>
    </div>
</div>