@php
/*
--------------------------------------------------------------------------
| Categories widget
|---------------------------------------------------------------------------
| Responsibility: Displaying categories of questions.
*/
@endphp

<div class="right-widget branding-border" style="">
    <div class="p-2 sidebar-widget b-c-b" style="border-bottom:1px solid lightgray;color:white;background-image:url({{asset('images/tech-design.png')}})
        ;background-repeat:no-repeat;background-position:right top;">
        <i class="fas fa-align-left"></i> Categories
    </div>
    <div class="p-2">
        <ul id="categories_menu" class="list-unstyled">
            <li>কম্পিউটার (48)</li>
            <li>কম্পিউটার (48)</li>
            <li>কম্পিউটার (48)</li>
            <li>কম্পিউটার (48)</li>
            <li>কম্পিউটার (48)</li>
        </ul>
    </div>
</div>