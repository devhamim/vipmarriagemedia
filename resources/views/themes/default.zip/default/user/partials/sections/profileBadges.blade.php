<div class="profile-badges-container">
    <div class="profile-badges container">
        <h4>Your Badges:</h4>
        <ul class="badges-list">
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
            <li>Badge</li>
        </ul>
    </div>
</div>
