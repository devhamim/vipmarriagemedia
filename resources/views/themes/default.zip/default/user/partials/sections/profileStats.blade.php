<section>
    <div class="profile-stats-container">
        <div class="profile-stats container">
            <div class="row">
                <div class="question-count col-md-3">
                    <i class="bi bi-question-circle"></i> 999 Questions
                </div>
                <div class="answer-count col-md-3">
                    <i class="bi bi-chat-left-text"></i> 99 Answers
                </div>
                <div class="upvote-count col-md-3">
                    <i class="bi bi-capslock-fill"></i> 123 Upvotes
                </div>
                <div class="points-count col-md-3">
                    <i class="bi bi-award"></i> 25.4K Points
                </div>
            </div>
        </div>
    </div>
</section>
