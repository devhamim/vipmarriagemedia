@extends('user.layouts.primaryLayout')
@section('sitebody')
<h1>Verify your email first to proceed further.</h1>
@endsection
