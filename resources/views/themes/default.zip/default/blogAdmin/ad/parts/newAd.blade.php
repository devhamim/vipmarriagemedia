    <section class="content-header">
      <h1>
        New Advertisement Space
        <small>Create</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-plus"></i> New Advertisement Space</a></li>
        <li class="active">create</li>
      </ol>
    </section>

    <section class="content">

    @include('blogAdmin.ad.includes.forms.newAdForm')

</section>



