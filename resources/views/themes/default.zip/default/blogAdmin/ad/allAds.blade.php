@extends('blogAdmin.layouts.blogAdminMaster')

@push('css')
@endpush

@section('content')
  @include('blogAdmin.ad.parts.allAds')
@endsection

@push('js')
@endpush
