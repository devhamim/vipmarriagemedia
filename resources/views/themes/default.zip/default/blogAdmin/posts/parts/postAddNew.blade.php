    <section class="content-header">
      <h1>
        New Post
        <small>Create</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-plus"></i> New Post</a></li>
        <li class="active">create</li>
      </ol>
    </section>

    <section class="content">

    @include('blogAdmin.posts.includes.forms.postAddNew')

</section>

