@extends('blogAdmin.layouts.blogAdminMaster')
@push('css')
@endpush

@section('content')
  @include('blogAdmin.posts.parts.postsAll')
@endsection


@push('js')
@endpush
