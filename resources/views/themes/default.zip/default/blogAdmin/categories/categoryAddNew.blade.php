@extends('admin.master.dashboardmaster')
@push('css')
@endpush

@section('content')
  @include('blogAdmin.categories.parts.categoryAddNew')
@endsection


@push('js')
@endpush
