<img id="profile_pic" align="left" class="fb-image-profile w3-animate-zoom img-thumbnail img-fluid" src="{{asset('storage/users/pp/' .$user->profile_img)}}" alt="Profile image example"/>
<br>
