@extends('admin.layouts.adminMaster')

@push('css')
@endpush

@section('content')

  @include('admin.payments.parts.paymentHistoryForUser')

@endsection


@push('js')
 

@endpush
