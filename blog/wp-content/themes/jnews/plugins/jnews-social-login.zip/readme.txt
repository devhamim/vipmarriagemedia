Change Log :

== 7.0.4 ==
- [IMPROVEMENT] Upgrade Linkedin API version (v2) 

== 7.0.3 ==
- [BUG] Fix conflict with Instant Articles for WP

== 7.0.2 ==
- [BUG] Remove session to avoid loopback issue on Site Health
- [IMPROVEMENT] Replace .ready() with .on()

== 7.0.1 ==
- [BUG] Fix social login issue with cache

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.2 ==
- [BUG] Fix issue with implode() function PHP 7.4

== 6.0.1 ==
- [BUG] Fix Google login issue

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.1 ==
- [IMPROVEMENT] Add filter to force disable social login and registration feature

== 1.0.0 ==
- First Release
