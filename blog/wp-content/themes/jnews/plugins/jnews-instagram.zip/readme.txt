Change Log :

== 7.0.5 ==
- [IMPROVEMENT] Add purge cache option

== 7.0.4 ==
- [BUG] Fixed Instagram shortcode issue

== 7.0.3 ==
- [IMPROVEMENT] Instagram using new API

== 7.0.2 ==
- [IMPROVEMENT] Instagram fetch data without proxy

== 7.0.1 ==
- [IMPROVEMENT] Show warning message for admin only.

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.1 [Development] ==
- [IMPROVEMENT] Better Instagram handler

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.1 ==
- [BUG] Fixed Instagram feed issue

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.1 ==
- [IMPROVEMENT] Support Instagram API to fetch Instagram feed
- [BUG] Fixed Instagram feed issue

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.1 ==
- [BUG] Fix feed issue

== 1.0.0 ==
- First Release
