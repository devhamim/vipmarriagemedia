Change Log :

== 7.0.2 ==
- [IMPROVEMENT] Replace .bind() with .on() and .unbind() with .off()

== 7.0.1 ==
- [IMPROVEMENT] Better animation for login form popup

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0
- [BUG] Fix Undefined variable

== 6.0.1 ==
- [BUG] Fix popup login issue

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.1 ==
- [IMPROVEMENT] Use .on()

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.2 ==
- [BUG] Fix undefined label index issue on account page

== 2.0.1 ==
- [IMPROVEMENT] Use modified date instead creation date on post meta date

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.3 ==
- [IMPROVEMENT] Add new archive template for liked and disliked post
- [BUG] Fix issue login form not showing when using like

== 1.0.2 ==
- [IMPROVEMENT] Prevent plugin conflict by changing ajax_url variable name

== 1.0.1 ==
- [BUG] Fix undefined variable issue

== 1.0.0 ==
- First Release
